#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "threads/interrupt.h"
#include "list.h"

void syscall_init (void);

// 	Syscall functions declarations - Project 2 Phase 2
//	Refer - https://static1.squarespace.com/static/5b18aa0955b02c1de94e4412/t/5b85fad2f950b7b16b7a2ed6/1535507195196/Pintos+Guide
//	Refer for syscalls to be implemented - http://web.stanford.edu/class/cs140/projects/pintos/pintos_3.html#SEC45

#define SYSCALL_MAX_ARGS 3 	// Syscalls take up to max 3 args
void is_valid_pointer(const void *ptr);
void is_valid_ptr_byte(const void *ptr);

void get_args_from_stack(int *ptr, int *args, int num_of_args);
void syscall_exit(int status);
int syscall_write(int fd, const void *buffer, unsigned size);
void syscall_halt(void);
typedef int pid_t; // To conform to the pintos manual standards of syscall definitions.
pid_t syscall_exec(const char *cmd_line);
int syscall_wait(pid_t pid);
//struct lock file_lock; // To make sure no concurrent threads can access the same file at the same time. Initialised in thread.c
// Helper struct to handle file handling
struct thread_file
  {
    int fd;
    struct file* file;
    struct list_elem file_elem;
  };
struct thread_file *find_file_by_fd (int fd);
bool syscall_create(const char *file, unsigned initial_size);
bool syscall_remove(const char *file);
int syscall_open(const char *file);
int syscall_filesize(int fd);
int syscall_read(int fd, char *buffer, unsigned size);
void syscall_seek(int fd, unsigned pos);
unsigned syscall_tell(int fd);
void syscall_close(int fd);
#endif /* userprog/syscall.h */
