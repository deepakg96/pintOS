#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "devices/shutdown.h"
#include "process.h"
#include "threads/synch.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/malloc.h"
#include "devices/input.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

// Stack layout for System calls.
/*
 f->esp	-----------------------------
   		| SYS_CODE |
   		-----------------------------
   		| arg[0] ptr -OR- int_value |
   		-----------------------------
   		| arg[1] ptr -OR- int_value |
   		-----------------------------
   		| arg[2] ptr -OR- int_value |
   		-----------------------------
 */

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
//  printf ("system call!\n");
//  thread_exit ();


	int *p = f->esp; 	// Get stack pointer
	
	is_valid_pointer((const void*)p);	// Check if the pointer is pointing to valid memory

	int syscall_code = *p;	// Stack pointer always points to syscall code whenever a sys call is made
	//printf("syscall_code is %d\n", syscall_code);	

	int args_in_stack[SYSCALL_MAX_ARGS];	// Before executing syscalls, gets the args from the stack. 
	
	// All the syscalls needed for project 2. Refer /lib/syscall-nr.h
	switch (syscall_code)
	{	
		case SYS_HALT:	// HALT() does not take any parameters.
						syscall_halt();
						break;
		
		case SYS_EXIT:	// EXIT() system call will have just 1 value in the stack. 
						// args_in_stack[0] = exit code -- *(p+1)
						get_args_from_stack(p, &args_in_stack[0], 1);
						syscall_exit(args_in_stack[0]);	
						break;
		
		case SYS_EXEC:	// EXEC() system call will have just 1 value in the stack.
						// args_in_stack[0] = cmd_line executable passed to it -- *(p+1)

						get_args_from_stack(p, &args_in_stack[0], 1);
						// Validate if the buffer pointer is pointing to a valid location in memory.
                        is_valid_pointer((const void*)args_in_stack[0]);
						
						f->eax = syscall_exec((const char*)args_in_stack[0]);
						break;
		
		case SYS_WAIT: 	// WAIT() system call takes one argument.
						// args_in_stack[0] = pid of the child process -- *(p+1)
						get_args_from_stack(p, &args_in_stack[0], 1);

						f->eax = syscall_wait((pid_t)args_in_stack[0]);	
						break;
		
		case SYS_CREATE:// CREATE() system call takes two arguments.
						// args_in_stack[0] = file name -- *(p+1)
						// args_in_stack[1] = size of the file -- *(p+2)
						get_args_from_stack(p, &args_in_stack[0], 2);

						// Check if the file char pointed to by the pointer is valid.
						is_valid_pointer((const void *)args_in_stack[0]);
						
						f->eax = syscall_create((const char *)args_in_stack[0], (unsigned)args_in_stack[1]);	
						break;
		
		case SYS_REMOVE:// REMOVE() system call takes just one argument.
						// args_in_stack[0] = file name -- *(p+1)
						get_args_from_stack(p, &args_in_stack[0], 1);

						// Check for validity.
						is_valid_pointer((const char *)args_in_stack[0]);
						
						f->eax = syscall_remove((const char *)args_in_stack[0]);	
						break;
		
		case SYS_OPEN:  // OPEN() system call takes one argument.
						// args_in_stack[0] = file name -- *(p+1)
						
						get_args_from_stack(p, &args_in_stack[0], 1);
						// Check for validity
						is_valid_pointer((const char *)args_in_stack[0]);

						f->eax = syscall_open((const char *)args_in_stack[0]);
						break;
		
		case SYS_FILESIZE:
						// FILESIZE() system call takes one argument.
						// args_in_stack[0] = fd -- *(p+1)

						get_args_from_stack(p, &args_in_stack[0], 1);
						// Changing this from void to int function					
						lock_acquire(&file_lock);
						f->eax = syscall_filesize((int)args_in_stack[0]);		
						lock_release(&file_lock);
						break;
		
		case SYS_READ:  // READ() system call takes 3 arguments.
						// args_in_stack[0] = fd -- *(p+1)
						// args_in_stack[1] = buffer -- *(p+2) -- Modifying this field to char* instead of void*
						// args_in_stack[2] = size -- *(p+3)

						get_args_from_stack(p, &args_in_stack[0], 3);
						// Check for validity
						is_valid_pointer((const void*)args_in_stack[1]);

						f->eax = syscall_read(args_in_stack[0], (void *)args_in_stack[1], (unsigned)args_in_stack[2]);	
						break;
		
		case SYS_WRITE:	// WRITE() system call will have 3 values in the stack.
						// args_in_stack[0] = file descriptor -- *(p + 1)
						// args_in_stack[1] = buffer --	*(p + 2)
						// args_in_stack[2] = size of the buffer -- *(p + 3)
					
						get_args_from_stack(p, &args_in_stack[0], 3);
						// Validate if the buffer pointer is valid.
						is_valid_pointer((const void*)args_in_stack[1]);
						
						f->eax = syscall_write(args_in_stack[0], (const void *)args_in_stack[1], (unsigned)args_in_stack[2]);
						break;
	
		case SYS_SEEK:  // SEEK() system call takes 2 arguments.
						// args_in_stack[0] = file descriptor -- *(p+1)
						// args_in_stack[1] = position to be seeked -- *(p+2)

						get_args_from_stack(p, &args_in_stack[0], 2);

						lock_acquire(&file_lock);
						syscall_seek(args_in_stack[0], (unsigned)args_in_stack[1]);
						lock_release(&file_lock);
						break;
		
		case SYS_TELL:	// TELL() system call takes 1 argument.
						// args_in_stack[0] = fd -- *(p+1)
						get_args_from_stack(p, &args_in_stack[0], 1);

						lock_acquire(&file_lock);
						f->eax = syscall_tell(args_in_stack[0]);	
						lock_release(&file_lock);
						break;
		
		case SYS_CLOSE: // CLOSE() system call just takes one argument.
						// args_in_stack[0] = file descriptor -- *(p+1)
						get_args_from_stack(p, &args_in_stack[0], 1);

						lock_acquire(&file_lock);
						syscall_close((int)args_in_stack[0]);	
						lock_release(&file_lock);
						break;
		
		default:		syscall_exit(-1);	
						break;

	}
}

void is_valid_ptr_byte(const void *ptr)
{
	// 0x08048000 is the starting address of user code segment. So pointer should always be within 0x08048000 and PHYS_BASE
	if (ptr == NULL || !is_user_vaddr(ptr) || ptr < (const void *)0x08048000 || ptr > PHYS_BASE)
	{
		syscall_exit(-1);
	}

	// Check if the pointer is in valid page.
	void *page_ptr = pagedir_get_page (thread_current ()->pagedir, ptr);
	if (page_ptr == NULL)
	{
		syscall_exit(-1);
	}
}

void is_valid_pointer (const void *ptr)
{
	is_valid_ptr_byte((int *)ptr);
    
	// Check if every dereferenced byte is valid.
	for (int i = 0; i < (int)sizeof(int); i++)
	{
		is_valid_ptr_byte((char *)ptr + i);
	}
}

void get_args_from_stack(int *ptr, int *args, int num_of_args)
{
	int i;
  	for (i = 0; i < num_of_args; i++)
    {
      	is_valid_pointer((const void *) (ptr + i + 1));
      	args[i] = *(ptr + i + 1);
    }
}

void syscall_exit(int status)
{
	//printf("%s: exit(%d)\n", thread_current()->name, status);
	thread_current()->exit_code = status;
	thread_exit();
}

int syscall_write(int fd, const void *buffer, unsigned size)
{
	int bytes = -1;
	if (fd == 1)	// fd=1 indicates STDOUT
    {
      putbuf(buffer, size); 
      return size;
    }
	else
	{
		struct thread_file * tf = find_file_by_fd(fd);
		if (tf)
		{
			lock_acquire(&file_lock);
			bytes = file_write (tf->file, buffer, size);
			lock_release(&file_lock);
			return bytes;
		}
		else
		{
			return -1;
		}
	}
	return size;	
}

void syscall_halt(void)
{
	shutdown_power_off();
}

pid_t syscall_exec(const char *cmd_line)
{
	if (!cmd_line)
	{
		return -1;
	}
	pid_t child_pid = process_execute(cmd_line);
	return child_pid;
}

int syscall_wait(pid_t pid)
{
	return process_wait(pid);
}

bool syscall_create(const char *file, unsigned initial_size)
{
	lock_acquire(&file_lock);
	bool status = filesys_create(file, initial_size);
	lock_release(&file_lock);
	return status;
}

bool syscall_remove(const char *file)
{
	lock_acquire(&file_lock);
	bool status = filesys_remove(file);
	lock_release(&file_lock);
	return status;
}

struct thread_file *find_file_by_fd (int fd) 
{                                   
  struct list_elem *elem;
  struct thread_file *tf=NULL;

  struct list *f = &thread_current()->files;                              
  for (elem = list_begin (f); elem!= list_end (f); elem = list_next (elem)){
    tf = list_entry (elem, struct thread_file, file_elem);

    if (tf->fd == fd)                                       
      return tf;                                                 
  }                                                                            
  return NULL;                                                                 
}        

int syscall_open(const char *file)
{
	lock_acquire(&file_lock);
	struct file *file_ptr = filesys_open(file);
	lock_release(&file_lock);

	if (file_ptr)
	{
		struct thread_file *tf = malloc(sizeof(struct thread_file));
    	tf->file = file_ptr;
    	tf->fd = thread_current()->fd;
		thread_current()->fd++;
    	list_push_back (&thread_current()->files, &tf->file_elem);	
		return tf->fd;
	}
	return -1;

}

int syscall_filesize(int fd)
{
  struct thread_file * tf = find_file_by_fd(fd);
  if (tf)
  { 
    return file_length (tf->file);
  } 
  else
  { 
    return -1;
  }
  
}

int syscall_read(int fd, char *buffer, unsigned size)
{
	int bytes = -1;
	if (fd == 0)
	{
		for (int i=0; i<(int)size; i++)
		{
			buffer[i] = input_getc();
		}
	}
	else
	{
		struct thread_file * tf = find_file_by_fd(fd);
		if (tf)
    	{
			lock_acquire(&file_lock);
      		bytes = file_read (tf->file, buffer, size);
			lock_release(&file_lock);
			return bytes;
		}
		else
			{
			return -1;}
	}
	return -1;
}

void syscall_seek(int fd, unsigned position)
{
  	struct thread_file *file_temp = find_file_by_fd(fd);
  	if (file_temp)
  	{
    	file_seek (file_temp->file, position);
  	}
}

unsigned syscall_tell(int fd)
{
	struct thread_file *file_temp = find_file_by_fd(fd);
  	if (file_temp)
  	{ 
    	return file_tell (file_temp->file);
  	}
	else
	{
    	return -1;
  	}
	return -1;
}

void syscall_close(int fd)
{
	struct thread_file * tf = find_file_by_fd(fd);
	if (tf)
  	{
    	file_close (tf->file);
    	list_remove (&tf->file_elem);
    	free (tf);
  }
}
