#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "threads/interrupt.h"

void syscall_init (void);

// 	Syscall functions declarations - Project 2 Phase 2
//	Refer - https://static1.squarespace.com/static/5b18aa0955b02c1de94e4412/t/5b85fad2f950b7b16b7a2ed6/1535507195196/Pintos+Guide
//	Refer for syscalls to be implemented - http://web.stanford.edu/class/cs140/projects/pintos/pintos_3.html#SEC45

#define SYSCALL_MAX_ARGS 3 	// Syscalls take up to max 3 args
void is_valid_pointer(const void *ptr);
void get_args_from_stack(int *ptr, int *args, int num_of_args);
void syscall_exit(int status);
int syscall_write(int fd, const void *buffer, unsigned size);

#endif /* userprog/syscall.h */
