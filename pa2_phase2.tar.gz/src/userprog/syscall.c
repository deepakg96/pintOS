#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

// Stack layout for System calls.
/*
 f->esp	-----------------------------
   		| SYS_CODE |
   		-----------------------------
   		| arg[0] ptr -OR- int_value |
   		-----------------------------
   		| arg[1] ptr -OR- int_value |
   		-----------------------------
   		| arg[2] ptr -OR- int_value |
   		-----------------------------
 */

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
//  printf ("system call!\n");
//  thread_exit ();


	int *p = f->esp; 	// Get stack pointer
	
	is_valid_pointer((const void*)p);	// Check if the pointer is pointing to valid memory

	int syscall_code = *p;	// Stack pointer always points to syscall code whenever a sys call is made
	//printf("syscall_code is %d\n", syscall_code);	

	int args_in_stack[SYSCALL_MAX_ARGS];	// Before executing syscalls, gets the args from the stack. 
	
	void *phys_page_ptr;	// Needed to check if virtual user address maps to a known memory
	
	// All the syscalls needed for project 2. Refer /lib/syscall-nr.h
	switch (syscall_code)
	{	
		case SYS_HALT:	
						break;
		
		case SYS_EXIT:	// EXIT() system call will have just 1 value in the stack. 
						// args_in_stack[0] = exit code -- *(p+1)
						
						get_args_from_stack(p, &args_in_stack[0], 1);
						syscall_exit(args_in_stack[0]);	
						break;
		
		case SYS_EXEC: 	
						break;
		
		case SYS_WAIT: 	
						break;
		
		case SYS_CREATE: 	
						break;
		
		case SYS_REMOVE: 	
						break;
		
		case SYS_OPEN:	
						break;
		
		case SYS_FILESIZE:	
						break;
		
		case SYS_READ:	
						break;
		
		case SYS_WRITE:	// WRITE() system call will have 3 values in the stack.
						// args_in_stack[0] = file descriptor -- *(p + 1)
						// args_in_stack[1] = buffer --	*(p + 2)
						// args_in_stack[2] = size of the buffer -- *(p + 3)
					
						get_args_from_stack(p, &args_in_stack[0], 3);
						
						// Validate if the buffer pointer is valid.
						is_valid_pointer((const void*)args_in_stack[1]);

						// Check if the user address maps to a known physical memory.
						phys_page_ptr = pagedir_get_page(thread_current()->pagedir, (const void *)args_in_stack[1]);
        				if (phys_page_ptr == NULL)
        				{
          					syscall_exit(-1);
        				}						
						f->eax=syscall_write(args_in_stack[0], (const void *)args_in_stack[1], (unsigned)args_in_stack[2]);
						break;
	
		case SYS_SEEK:	
						break;
		
		case SYS_TELL:	
						break;
		
		case SYS_CLOSE:	
						break;
		
		default:		syscall_exit(-1);	
						break;

	}
}

void is_valid_pointer(const void *ptr)
{
	// 0x08048000 is the starting address of user code segment. So pointer should always be within 0x08048000 and PHYS_BASE
	if (ptr == NULL || !is_user_vaddr(ptr) || ptr < (const void *)0x08048000 || ptr > PHYS_BASE)
	{
		syscall_exit(-1);
	}
}

void get_args_from_stack(int *ptr, int *args, int num_of_args)
{
	int i;
  	for (i = 0; i < num_of_args; i++)
    {
      	is_valid_pointer((const void *) (ptr + i + 1));
      	args[i] = *(ptr + i + 1);
    }
}

void syscall_exit(int status)
{
	printf("%s: exit(%d)\n", thread_current()->name, status);
	thread_exit();
}

int syscall_write(int fd, const void *buffer, unsigned size)
{
	if (fd == 1)	// fd=1 indicates STDOUT
    {
      putbuf(buffer, size); 
      return size;
    }
	return size;	
}
